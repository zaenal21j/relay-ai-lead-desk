<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('leads', function (Blueprint $table) {
            $table->string('ai_recommendation', 24)->nullable()->after('score');
            $table->text('ai_reasoning')->nullable()->after('ai_recommendation');
            $table->timestamp('ai_generated_at')->nullable()->after('ai_reasoning');
            $table->longText('reply_draft')->nullable()->after('ai_generated_at');
            $table->timestamp('reply_approved_at')->nullable()->after('reply_draft');
            $table->foreignId('reply_approved_by')->nullable()->after('reply_approved_at')->constrained('users')->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('leads', function (Blueprint $table) {
            $table->dropForeign(['reply_approved_by']);
            $table->dropColumn(['ai_recommendation', 'ai_reasoning', 'ai_generated_at', 'reply_draft', 'reply_approved_at', 'reply_approved_by']);
        });
    }
};
