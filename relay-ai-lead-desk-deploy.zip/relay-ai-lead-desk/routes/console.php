<?php

use App\Models\User;
use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Artisan::command('admin:grant {email}', function (string $email): int {
    $user = User::query()->where('email', $email)->first();

    if (! $user) {
        $this->error('No account with that email exists. Register and verify it first.');

        return 1;
    }

    $user->forceFill(['is_admin' => true])->save();
    $this->info('Administrator access granted.');

    return 0;
})->purpose('Grant administrator access to an existing account');
