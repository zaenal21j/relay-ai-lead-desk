<?php

use App\Http\Controllers\SocialAuthController;
use App\Livewire\Leads\Index;
use App\Services\OpenAiApiKey;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return auth()->check() ? redirect()->route('dashboard') : redirect()->route('login');
})->name('home');

Route::get('auth/{provider}/redirect', [SocialAuthController::class, 'redirect'])
    ->whereIn('provider', ['google', 'facebook'])
    ->name('social.redirect');

Route::get('auth/{provider}/callback', [SocialAuthController::class, 'callback'])
    ->whereIn('provider', ['google', 'facebook'])
    ->middleware('throttle:10,1')
    ->name('social.callback');

Route::get('auth/{provider}/link', [SocialAuthController::class, 'link'])
    ->whereIn('provider', ['google', 'facebook'])
    ->middleware(['auth', 'verified', 'password.confirm'])
    ->name('social.link');

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('dashboard', function (OpenAiApiKey $apiKey) {
        $leads = auth()->user()->leads();

        return view('dashboard', [
            'newLeads' => (clone $leads)->where('status', 'new')->count(),
            'needsReview' => (clone $leads)->where('status', 'review')->count(),
            'qualifiedLeads' => (clone $leads)->where('status', 'qualified')->count(),
            'totalLeads' => (clone $leads)->count(),
            'recentLeads' => (clone $leads)->latest()->limit(5)->get(),
            'aiConfigured' => $apiKey->isConfigured(auth()->id()),
        ]);
    })->name('dashboard');

    Route::get('leads', Index::class)->name('leads.index');
});

require __DIR__.'/settings.php';
