<x-layouts::app :title="__('Lead overview')">
    @php
        $qualificationRate = $totalLeads > 0 ? (int) round(($qualifiedLeads / $totalLeads) * 100) : 0;
        $metrics = [
            ['New leads', $newLeads, 'Awaiting first review', 'blue'],
            ['Needs review', $needsReview, 'Human attention needed', 'amber'],
            ['Qualified', $qualifiedLeads, $qualificationRate.'% of your pipeline', 'emerald'],
            ['Total pipeline', $totalLeads, 'In your workspace', 'violet'],
        ];
    @endphp
    <div class="mx-auto flex w-full max-w-7xl flex-1 flex-col gap-7 px-4 py-6 sm:px-6 lg:px-8">
        <div class="flex flex-wrap items-end justify-between gap-4">
            <div>
                <div class="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-[0.15em] text-zinc-500"><span>Relay AI</span><span class="text-zinc-300">/</span><span>Workspace</span></div>
                <h1 class="text-2xl font-semibold tracking-tight text-zinc-950 dark:text-white sm:text-3xl">Lead overview</h1>
                <p class="mt-1 text-sm text-zinc-600 dark:text-zinc-400">A clear view of new conversations and the next best action.</p>
            </div>
            <flux:button variant="primary" icon="plus" :href="route('leads.index')" wire:navigate>Add a lead</flux:button>
        </div>

        <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            @foreach ($metrics as [$label, $value, $note, $tone])
                <section class="rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm shadow-zinc-950/[0.025] dark:border-zinc-800 dark:bg-zinc-900">
                    <div class="flex items-center justify-between gap-3"><h2 class="text-sm font-medium text-zinc-600 dark:text-zinc-400">{{ $label }}</h2><span class="size-2 rounded-full {{ ['blue'=>'bg-blue-500','amber'=>'bg-amber-500','emerald'=>'bg-emerald-500','violet'=>'bg-violet-500'][$tone] }}"></span></div>
                    <p class="mt-4 text-3xl font-semibold tracking-tight text-zinc-950 dark:text-white">{{ $value }}</p><p class="mt-2 text-xs text-zinc-500 dark:text-zinc-400">{{ $note }}</p>
                </section>
            @endforeach
        </div>

        <div class="grid gap-5 xl:grid-cols-[minmax(0,1.65fr)_minmax(280px,0.85fr)]">
            <section class="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm shadow-zinc-950/[0.025] dark:border-zinc-800 dark:bg-zinc-900">
                <div class="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-100 px-5 py-4 dark:border-zinc-800"><div><h2 class="font-semibold text-zinc-950 dark:text-white">Recent leads</h2><p class="mt-0.5 text-xs text-zinc-500">Latest inbound requests in your workspace</p></div><a href="{{ route('leads.index') }}" wire:navigate class="text-sm font-medium text-blue-700 hover:text-blue-800 dark:text-blue-300">View all</a></div>
                <div class="overflow-x-auto"><table class="w-full min-w-[600px] text-left text-sm">
                    <thead class="bg-zinc-50 text-[11px] font-semibold uppercase tracking-wider text-zinc-500 dark:bg-zinc-950/50"><tr><th class="px-5 py-3">Contact</th><th class="px-4 py-3">Company</th><th class="px-4 py-3">Status</th><th class="px-5 py-3 text-right">Added</th></tr></thead>
                    <tbody class="divide-y divide-zinc-100 dark:divide-zinc-800">
                        @forelse ($recentLeads as $lead)
                            @php $tone = match ($lead->status) { 'qualified' => 'emerald', 'review' => 'amber', 'disqualified' => 'zinc', default => 'blue' }; $statusLabel = match ($lead->status) { 'qualified' => 'Qualified', 'review' => 'Needs review', 'disqualified' => 'Disqualified', default => 'New' }; @endphp
                            <tr class="transition hover:bg-zinc-50/80 dark:hover:bg-zinc-800/40"><td class="px-5 py-4"><div class="flex items-center gap-3"><span class="grid size-9 place-items-center rounded-full bg-zinc-100 text-xs font-semibold text-zinc-700 dark:bg-zinc-800 dark:text-zinc-200">{{ str($lead->name)->initials() }}</span><div><p class="font-medium text-zinc-900 dark:text-zinc-100">{{ $lead->name }}</p><p class="mt-0.5 text-xs text-zinc-500">{{ $lead->email }}</p></div></div></td><td class="px-4 py-4 text-zinc-600 dark:text-zinc-300">{{ $lead->company ?: '—' }}</td><td class="px-4 py-4"><span class="inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium {{ ['emerald'=>'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300','amber'=>'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300','blue'=>'bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300','zinc'=>'bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300'][$tone] }}">{{ $statusLabel }}</span></td><td class="px-5 py-4 text-right text-xs text-zinc-500">{{ $lead->created_at->diffForHumans() }}</td></tr>
                        @empty
                            <tr><td colspan="4" class="px-5 py-14 text-center"><p class="font-medium text-zinc-800 dark:text-zinc-200">No leads yet</p><p class="mt-1 text-sm text-zinc-500">Add an inbound request to start building your pipeline.</p><a href="{{ route('leads.index') }}" wire:navigate class="mt-3 inline-flex text-sm font-semibold text-blue-700 dark:text-blue-300">Add your first lead →</a></td></tr>
                        @endforelse
                    </tbody>
                </table></div>
                <div class="border-t border-zinc-100 px-5 py-3 text-xs text-zinc-500 dark:border-zinc-800">Only leads belonging to your account are shown.</div>
            </section>

            <div class="flex flex-col gap-5">
                <section class="rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm shadow-zinc-950/[0.025] dark:border-zinc-800 dark:bg-zinc-900">
                    <div class="flex items-center justify-between"><div><h2 class="font-semibold text-zinc-950 dark:text-white">Review queue</h2><p class="mt-0.5 text-xs text-zinc-500">Manual review remains in control</p></div><span class="grid size-9 place-items-center rounded-xl bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300">{{ $needsReview }}</span></div>
                    @if ($needsReview > 0)<p class="mt-4 text-sm leading-6 text-zinc-600 dark:text-zinc-400">{{ $needsReview }} lead{{ $needsReview === 1 ? '' : 's' }} {{ $needsReview === 1 ? 'is' : 'are' }} waiting for your review.</p>@else<p class="mt-4 text-sm leading-6 text-zinc-600 dark:text-zinc-400">No leads are waiting for review. You stay in control of every qualification decision.</p>@endif
                    <p class="mt-3 text-xs text-zinc-500">@if ($aiConfigured) AI suggestions are ready when you open a lead. Replies are never sent automatically. @else AI is optional. You can qualify leads and write replies manually; <a href="{{ route('ai.edit') }}" wire:navigate class="font-medium text-blue-700 underline dark:text-blue-300">configure it later</a> when you have a key. @endif</p>
                </section>
                <section class="rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm shadow-zinc-950/[0.025] dark:border-zinc-800 dark:bg-zinc-900">
                    <div class="flex items-center justify-between"><div><h2 class="font-semibold text-zinc-950 dark:text-white">Connections</h2><p class="mt-0.5 text-xs text-zinc-500">External services</p></div><span class="size-2 rounded-full bg-zinc-300"></span></div>
                    <div class="mt-4 flex items-center justify-between border-t border-zinc-100 pt-4 text-sm dark:border-zinc-800"><span class="text-zinc-700 dark:text-zinc-300">Google Sheets</span><span class="text-xs text-zinc-500">Not connected</span></div><div class="mt-3 flex items-center justify-between text-sm"><span class="text-zinc-700 dark:text-zinc-300">CRM webhook</span><span class="text-xs text-zinc-500">Not connected</span></div>
                </section>
            </div>
        </div>
    </div>
</x-layouts::app>
