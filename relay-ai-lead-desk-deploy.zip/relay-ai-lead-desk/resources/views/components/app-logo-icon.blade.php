<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40" {{ $attributes }}>
    <path fill="currentColor" d="M20 3.5 5.5 11.7v16.6L20 36.5l14.5-8.2V11.7L20 3.5Zm0 4.1 10.9 6.1v12.6L20 32.5 9.1 26.3V13.7L20 7.6Z"/>
    <path fill="currentColor" d="M20 11.1 13 15v8l7 3.9 7-3.9v-8l-7-3.9Zm0 4.1 3.3 1.8v4l-3.3 1.8-3.3-1.8v-4l3.3-1.8Z"/>
</svg>
