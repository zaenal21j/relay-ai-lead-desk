@php
    $providers = [
        'google' => ['name' => 'Google', 'mark' => 'G'],
        'facebook' => ['name' => 'Facebook', 'mark' => 'f'],
    ];
    $providerSettings = app(\App\Services\SocialProviderSettings::class);
    $configuredCount = collect($providers)->keys()->filter(fn ($provider) => $providerSettings->isConfigured($provider))->count();
@endphp

<div class="space-y-3">
    <div class="grid grid-cols-2 gap-3">
        @foreach ($providers as $provider => $details)
            @if ($providerSettings->isConfigured($provider))
                <a href="{{ route('social.redirect', $provider) }}" class="inline-flex min-h-11 items-center justify-center gap-2 rounded-lg border border-zinc-200 bg-white px-3 text-sm font-medium text-zinc-800 shadow-sm transition hover:bg-zinc-50 focus:outline-none focus:ring-2 focus:ring-blue-500/40 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:hover:bg-zinc-800">
                    <span aria-hidden="true" class="grid size-5 place-items-center rounded-full border border-zinc-200 text-xs font-bold dark:border-zinc-700">{{ $details['mark'] }}</span>
                    <span>{{ __('Continue with :provider', ['provider' => $details['name']]) }}</span>
                </a>
            @else
                <button type="button" disabled aria-disabled="true" title="OAuth credentials are not configured" class="inline-flex min-h-11 cursor-not-allowed items-center justify-center gap-2 rounded-lg border border-zinc-200 bg-zinc-50 px-3 text-center text-sm font-medium text-zinc-400 dark:border-zinc-800 dark:bg-zinc-900/50 dark:text-zinc-500">
                    <span aria-hidden="true" class="grid size-5 place-items-center rounded-full border border-current text-xs font-bold">{{ $details['mark'] }}</span>
                    <span>{{ __('Continue with :provider', ['provider' => $details['name']]) }}</span>
                </button>
            @endif
        @endforeach
    </div>

    @if ($configuredCount < count($providers))
        <p class="text-center text-xs leading-5 text-zinc-500">Google/Facebook sign-in will be enabled after OAuth credentials are configured. Email and password sign-in are ready now.</p>
    @endif

    <div class="relative py-1"><div class="absolute inset-0 flex items-center"><span class="w-full border-t border-zinc-200 dark:border-zinc-800"></span></div><div class="relative flex justify-center"><span class="bg-white px-3 text-xs uppercase tracking-wide text-zinc-400 dark:bg-zinc-950">{{ __('Or continue with email') }}</span></div></div>
</div>
