<?php

use App\Services\OpenAiApiKey;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Title;
use Livewire\Component;
use Flux\Flux;

new #[Title('AI settings')] class extends Component {
    public string $apiKey = '';

    public function save(): void
    {
        $validated = $this->validate([
            'apiKey' => ['required', 'string', 'max:500'],
        ]);

        DB::table('app_settings')->updateOrInsert(
            ['user_id' => auth()->id(), 'key' => 'openai_api_key'],
            ['value' => Crypt::encryptString(trim($validated['apiKey'])), 'updated_at' => now(), 'created_at' => now()],
        );

        $this->apiKey = '';
        $this->resetValidation();
        Flux::toast(variant: 'success', text: 'API key tersimpan dengan aman. Nilainya tidak akan ditampilkan kembali.');
    }

    public function remove(): void
    {
        DB::table('app_settings')->where('user_id', auth()->id())->where('key', 'openai_api_key')->delete();
        $this->apiKey = '';
        $this->resetValidation();
        Flux::toast(variant: 'success', text: 'API key dari pengaturan aplikasi sudah dihapus.');
    }

    #[Computed]
    public function keyResolver(): OpenAiApiKey
    {
        return app(OpenAiApiKey::class);
    }
}; ?>

<section class="w-full">
    @include('partials.settings-heading')

    <x-pages::settings.layout heading="AI integration" subheading="Configure the AI provider used to qualify leads and draft replies.">
        <div class="my-6 space-y-6">
            <div class="rounded-xl border border-zinc-200 p-4 dark:border-zinc-700">
                <div class="flex items-start justify-between gap-4">
                    <div>
                        <flux:heading size="sm">OpenAI API key</flux:heading>
                        @if ($this->keyResolver->isStoredInApp())
                            <flux:text class="mt-1">Key tersimpan di aplikasi dan dienkripsi. Nilai key tidak ditampilkan.</flux:text>
                        @elseif ($this->keyResolver->isConfigured())
                            <flux:text class="mt-1">AI memakai key dari konfigurasi server. Anda dapat menggantinya dengan key aplikasi di bawah.</flux:text>
                        @else
                            <flux:text class="mt-1">Belum ada key. Tambahkan API key untuk mengaktifkan kualifikasi lead dan draf balasan AI.</flux:text>
                        @endif
                    </div>
                    @if ($this->keyResolver->isConfigured())
                        <flux:badge color="green">Configured</flux:badge>
                    @else
                        <flux:badge color="zinc">Not configured</flux:badge>
                    @endif
                </div>
            </div>

            <form wire:submit="save" class="space-y-4">
                <flux:input wire:model="apiKey" :label="$this->keyResolver->isStoredInApp() ? 'Replace API key' : 'API key'" type="password" autocomplete="new-password" placeholder="Paste your API key" />
                <flux:text size="sm">Key disimpan terenkripsi di database. Setelah disimpan, kolom dikosongkan dan aplikasi hanya menampilkan statusnya.</flux:text>
                <flux:button variant="primary" type="submit">Save API key</flux:button>
            </form>

            @if ($this->keyResolver->isStoredInApp())
                <flux:separator />
                <div class="flex items-center justify-between gap-4">
                    <flux:text size="sm">Hapus key yang tersimpan di aplikasi. Jika ada key server, aplikasi akan kembali memakainya.</flux:text>
                    <flux:button variant="danger" wire:click="remove" wire:confirm="Hapus API key dari aplikasi?">Remove</flux:button>
                </div>
            @endif
        </div>
    </x-pages::settings.layout>
</section>
