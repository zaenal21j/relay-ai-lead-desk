<?php

use Illuminate\Support\Facades\Auth;
use App\Services\SocialProviderSettings;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Title;
use Livewire\Component;

new #[Title('Connections')] class extends Component {
    #[Computed]
    public function linkedProviders(): array
    {
        return Auth::user()->socialAccounts()->pluck('provider')->all();
    }
}; ?>

<section class="w-full">
    @include('partials.settings-heading')

    <x-pages::settings.layout heading="Connections" subheading="Manage sign-in methods connected to your Relay account.">
        <div class="my-6 space-y-4">
            @if (session('status'))
                <div role="status" class="rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-sm text-blue-800 dark:border-blue-900 dark:bg-blue-950/40 dark:text-blue-200">{{ session('status') }}</div>
            @endif

            @foreach (['google' => 'Google', 'facebook' => 'Facebook'] as $provider => $label)
                @php
                    $providerSettings = app(SocialProviderSettings::class);
                    $configured = $providerSettings->isConfigured($provider);
                    $connected = in_array($provider, $this->linkedProviders, true);
                @endphp
                <div class="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-zinc-200 p-4 dark:border-zinc-700">
                    <div>
                        <flux:heading size="sm">{{ $label }}</flux:heading>
                        <flux:text class="mt-1">
                            @if ($connected)
                                Connected to this account.
                            @elseif ($configured)
                                Available to connect after confirming your password.
                            @else
                                A system administrator needs to configure this provider.
                            @endif
                        </flux:text>
                    </div>
                    @if ($connected)
                        <flux:badge color="green">Connected</flux:badge>
                    @elseif ($configured)
                        <flux:button :href="route('social.link', $provider)" variant="outline">Connect {{ $label }}</flux:button>
                    @else
                        <flux:badge color="zinc">Not configured</flux:badge>
                    @endif
                    @unless ($configured)
                        <div class="w-full border-t border-zinc-100 pt-3 dark:border-zinc-800">
                            <p class="text-xs leading-5 text-zinc-500">Sign in with email and password while an administrator configures this provider.</p>
                            <p class="mt-2 text-xs text-zinc-500">Register this exact callback URL with {{ $label }}:</p>
                            <code class="mt-1 block break-all rounded-md bg-zinc-50 px-2 py-1.5 text-xs text-zinc-700 dark:bg-zinc-800 dark:text-zinc-200">{{ config("services.{$provider}.redirect") }}</code>
                        </div>
                    @endunless
                </div>
            @endforeach

            <flux:text size="sm">Provider access tokens are not stored. To sign in with a connected provider, use its button on the login page.</flux:text>
        </div>
    </x-pages::settings.layout>
</section>
