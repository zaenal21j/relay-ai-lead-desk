<?php

use App\Services\SocialProviderSettings;
use Flux\Flux;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Title;
use Livewire\Component;

new #[Title('Admin OAuth settings')] class extends Component {
    public string $googleClientId = '';
    public string $googleClientSecret = '';
    public string $facebookClientId = '';
    public string $facebookClientSecret = '';

    public function saveProvider(string $provider): void
    {
        abort_unless(in_array($provider, ['google', 'facebook'], true), 404);

        $clientIdProperty = $provider.'ClientId';
        $clientSecretProperty = $provider.'ClientSecret';
        $validated = $this->validate([
            $clientIdProperty => ['required', 'string', 'max:2048'],
            $clientSecretProperty => ['required', 'string', 'max:4096'],
        ]);

        app(SocialProviderSettings::class)->save(
            $provider,
            $validated[$clientIdProperty],
            $validated[$clientSecretProperty],
        );

        $this->reset([$clientIdProperty, $clientSecretProperty]);
        $this->resetValidation();

        Flux::toast(variant: 'success', text: ucfirst($provider).' credentials saved encrypted. Values are hidden after saving.');
    }

    public function removeProvider(string $provider): void
    {
        abort_unless(in_array($provider, ['google', 'facebook'], true), 404);

        app(SocialProviderSettings::class)->remove($provider);
        $this->reset([$provider.'ClientId', $provider.'ClientSecret']);
        $this->resetValidation();

        Flux::toast(variant: 'success', text: ucfirst($provider).' credentials removed. Any server environment credentials will be used as a fallback.');
    }

    #[Computed]
    public function providerStatuses(): array
    {
        $settings = app(SocialProviderSettings::class);

        return collect(['google', 'facebook'])->mapWithKeys(fn (string $provider) => [
            $provider => [
                'configured' => $settings->isConfigured($provider),
                'source' => $settings->source($provider),
                'callback' => config("services.{$provider}.redirect"),
            ],
        ])->all();
    }
}; ?>

<section class="w-full">
    @include('partials.settings-heading')

    <x-pages::settings.layout heading="Admin OAuth settings" subheading="Only administrators can manage the application-wide Google and Facebook sign-in credentials.">
        <div class="my-6 space-y-6">
            <div class="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-900 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
                Credentials are encrypted in the database with the Laravel application key. Values are cleared from this form after saving and are never shown again. Keep the same <code>APP_KEY</code> to preserve access to them.
            </div>

            @foreach (['google' => 'Google', 'facebook' => 'Facebook'] as $provider => $label)
                @php($status = $this->providerStatuses[$provider])
                <section class="space-y-4 rounded-xl border border-zinc-200 p-4 dark:border-zinc-700">
                    <div class="flex items-start justify-between gap-4">
                        <div>
                            <flux:heading size="sm">{{ $label }}</flux:heading>
                            <flux:text class="mt-1">
                                @if ($status['configured'])
                                    Credentials configured via {{ $status['source'] === 'admin' ? 'admin settings' : 'server environment' }}. Values are hidden.
                                @else
                                    Not configured. Email and password sign-in remain available.
                                @endif
                            </flux:text>
                        </div>
                        @if ($status['configured'])
                            <flux:badge color="green">Configured</flux:badge>
                        @else
                            <flux:badge color="zinc">Not configured</flux:badge>
                        @endif
                    </div>

                    <div>
                        <p class="text-xs text-zinc-500">Register this exact callback URL with {{ $label }}:</p>
                        <code class="mt-1 block break-all rounded-md bg-zinc-50 px-2 py-1.5 text-xs text-zinc-700 dark:bg-zinc-800 dark:text-zinc-200">{{ $status['callback'] }}</code>
                    </div>

                    <form wire:submit="saveProvider('{{ $provider }}')" class="space-y-4 border-t border-zinc-100 pt-4 dark:border-zinc-800">
                        <flux:input wire:model="{{ $provider }}ClientId" type="password" autocomplete="new-password" label="{{ $label }} Client ID" placeholder="Paste the client ID" />
                        <flux:input wire:model="{{ $provider }}ClientSecret" type="password" autocomplete="new-password" label="{{ $label }} Client Secret" placeholder="Paste the client secret" />
                        <div class="flex flex-wrap justify-end gap-2">
                            @if ($status['source'] === 'admin')
                                <flux:button type="button" variant="danger" wire:click="removeProvider('{{ $provider }}')" wire:confirm="Remove the {{ $label }} credentials stored in admin settings?">Remove saved credentials</flux:button>
                            @endif
                            <flux:button type="submit" variant="primary">Save {{ $label }} credentials</flux:button>
                        </div>
                    </form>
                </section>
            @endforeach

            <flux:text size="sm">The first account registered in local development becomes the administrator. In production, grant admin access from the server after account creation with <code>php artisan admin:grant user@example.com</code>.</flux:text>
        </div>
    </x-pages::settings.layout>
</section>
