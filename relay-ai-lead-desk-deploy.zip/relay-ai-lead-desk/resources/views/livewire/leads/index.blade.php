<div class="mx-auto flex w-full max-w-7xl flex-1 flex-col gap-6 px-4 py-6 sm:px-6 lg:px-8">
    <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
            <div class="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-[0.15em] text-zinc-500"><a href="{{ route('dashboard') }}" wire:navigate>Workspace</a><span class="text-zinc-300">/</span><span>Leads</span></div>
            <h1 class="text-2xl font-semibold tracking-tight text-zinc-950 dark:text-white sm:text-3xl">Leads</h1>
            <p class="mt-1 text-sm text-zinc-600 dark:text-zinc-400">Capture requests, qualify opportunities, and keep every next step visible.</p>
        </div>
        <flux:button variant="primary" icon="plus" wire:click="openCreateModal">Add lead</flux:button>
    </div>

    @if ($notice)
        <div role="status" class="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800 dark:border-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200">{{ $notice }}</div>
    @endif

    <section class="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm shadow-zinc-950/[0.025] dark:border-zinc-800 dark:bg-zinc-900">
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-100 p-4 dark:border-zinc-800 sm:px-5">
            <div class="flex flex-1 flex-wrap gap-3">
                <div class="min-w-52 flex-1 sm:max-w-sm">
                    <flux:input wire:model.live.debounce.300ms="search" type="search" placeholder="Search name, email, company…" icon="magnifying-glass" aria-label="Search leads" />
                </div>
                <select wire:model.live="status" aria-label="Filter by status" class="rounded-lg border-zinc-200 bg-white py-2 pl-3 pr-8 text-sm text-zinc-700 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200">
                    <option value="all">All statuses</option><option value="new">New</option><option value="review">Needs review</option><option value="qualified">Qualified</option><option value="disqualified">Disqualified</option>
                </select>
            </div>
            <p class="text-xs text-zinc-500">Your workspace only</p>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full min-w-[720px] text-left text-sm">
                <thead class="bg-zinc-50 text-[11px] font-semibold uppercase tracking-wider text-zinc-500 dark:bg-zinc-950/50">
                    <tr><th class="px-5 py-3">Contact</th><th class="px-4 py-3">Company / source</th><th class="px-4 py-3">Status</th><th class="px-4 py-3">Score</th><th class="px-5 py-3 text-right">Added</th></tr>
                </thead>
                <tbody class="divide-y divide-zinc-100 dark:divide-zinc-800">
                    @forelse ($this->leads as $lead)
                        @php
                            $tone = match ($lead->status) { 'qualified' => 'emerald', 'review' => 'amber', 'disqualified' => 'zinc', default => 'blue' };
                            $statusLabel = match ($lead->status) { 'qualified' => 'Qualified', 'review' => 'Needs review', 'disqualified' => 'Disqualified', default => 'New' };
                        @endphp
                        <tr wire:key="lead-{{ $lead->id }}" class="transition hover:bg-zinc-50/80 dark:hover:bg-zinc-800/40">
                            <td class="px-5 py-4"><button type="button" wire:click="viewLead({{ $lead->id }})" class="flex items-center gap-3 text-left"><span class="grid size-9 shrink-0 place-items-center rounded-full bg-zinc-100 text-xs font-semibold text-zinc-700 dark:bg-zinc-800 dark:text-zinc-200">{{ str($lead->name)->initials() }}</span><span><span class="block font-medium text-zinc-900 dark:text-zinc-100">{{ $lead->name }}</span><span class="mt-0.5 block text-xs text-zinc-500">{{ $lead->email }}</span></span></button></td>
                            <td class="px-4 py-4"><span class="block text-zinc-700 dark:text-zinc-300">{{ $lead->company ?: '—' }}</span><span class="mt-0.5 block text-xs text-zinc-500">{{ $lead->source ?: 'Direct' }}</span></td>
                            <td class="px-4 py-4"><span class="inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium {{ ['emerald'=>'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300','amber'=>'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300','blue'=>'bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300','zinc'=>'bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300'][$tone] }}">{{ $statusLabel }}</span></td>
                            <td class="px-4 py-4 text-zinc-500">{{ $lead->score !== null ? $lead->score.' / 100' : '—' }}</td>
                            <td class="px-5 py-4 text-right text-xs text-zinc-500">{{ $lead->created_at->diffForHumans() }}</td>
                        </tr>
                    @empty
                        <tr><td colspan="5" class="px-5 py-16 text-center"><div class="mx-auto grid size-12 place-items-center rounded-2xl bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300"><flux:icon name="user-group" class="size-6" /></div><h2 class="mt-4 font-semibold text-zinc-900 dark:text-zinc-100">{{ $search || $status !== 'all' ? 'No matching leads' : 'Your lead list is ready' }}</h2><p class="mx-auto mt-1 max-w-sm text-sm text-zinc-500">{{ $search || $status !== 'all' ? 'Try another search or status filter.' : 'Add your first lead to start organizing new opportunities in one place.' }}</p>@if (!$search && $status === 'all')<flux:button class="mt-4" variant="primary" icon="plus" wire:click="openCreateModal">Add your first lead</flux:button>@endif</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($this->leads->hasPages())<div class="border-t border-zinc-100 px-5 py-3 dark:border-zinc-800">{{ $this->leads->links() }}</div>@endif
    </section>

    <flux:modal name="new-lead" wire:model="showCreateModal" class="md:w-[34rem]">
        <form wire:submit="saveLead" class="space-y-5">
            <div><flux:heading size="lg">Add a lead</flux:heading><flux:subheading>Save an inbound request to your private workspace.</flux:subheading></div>
            <div class="grid gap-4 sm:grid-cols-2">
                <flux:input wire:model="name" label="Full name" placeholder="Jordan Lee" required />
                <flux:input wire:model="email" type="email" label="Email address" placeholder="jordan@company.com" required />
                <flux:input wire:model="company" label="Company" placeholder="Company name" />
                <flux:input wire:model="source" label="Source" placeholder="Website, referral…" />
            </div>
            <flux:textarea wire:model="message" label="Request or context" placeholder="What does this person need help with?" rows="4" />
            <div class="flex justify-end gap-2"><flux:modal.close><flux:button variant="outline" type="button">Cancel</flux:button></flux:modal.close><flux:button variant="primary" type="submit">Save lead</flux:button></div>
        </form>
    </flux:modal>

    <flux:modal name="lead-details" :show="$selectedLeadId !== null" class="max-h-[90vh] overflow-y-auto md:w-[44rem]" @close="closeLead">
        @if ($this->selectedLead)
            <div class="space-y-6">
                <div><flux:heading size="lg">{{ $this->selectedLead->name }}</flux:heading><flux:subheading>{{ $this->selectedLead->email }}{{ $this->selectedLead->company ? ' · '.$this->selectedLead->company : '' }}</flux:subheading></div>
                <div class="rounded-xl bg-zinc-50 p-4 dark:bg-zinc-800/60"><p class="text-xs font-semibold uppercase tracking-wider text-zinc-500">Request context</p><p class="mt-2 whitespace-pre-wrap text-sm leading-6 text-zinc-700 dark:text-zinc-300">{{ $this->selectedLead->message ?: 'No message provided.' }}</p></div>
                <div class="grid gap-3 sm:grid-cols-2"><div><p class="text-xs text-zinc-500">Source</p><p class="mt-1 text-sm text-zinc-800 dark:text-zinc-200">{{ $this->selectedLead->source ?: 'Direct' }}</p></div><div><p class="text-xs text-zinc-500">Pipeline status · you control this</p><select wire:change="updateStatus({{ $this->selectedLead->id }}, $event.target.value)" class="mt-1 w-full rounded-lg border-zinc-200 bg-white py-2 text-sm dark:border-zinc-700 dark:bg-zinc-900"><option value="new" @selected($this->selectedLead->status === 'new')>New</option><option value="review" @selected($this->selectedLead->status === 'review')>Needs review</option><option value="qualified" @selected($this->selectedLead->status === 'qualified')>Qualified</option><option value="disqualified" @selected($this->selectedLead->status === 'disqualified')>Disqualified</option></select></div></div>

                <section class="rounded-2xl border border-blue-100 bg-blue-50/60 p-4 dark:border-blue-950 dark:bg-blue-950/20 sm:p-5">
                    <div class="flex flex-wrap items-start justify-between gap-3"><div><p class="text-xs font-semibold uppercase tracking-wider text-blue-700 dark:text-blue-300">AI qualification</p><h3 class="mt-1 font-semibold text-zinc-900 dark:text-zinc-100">Suggested fit and reply</h3></div>
                        @if ($this->isAiAvailable)
                            <flux:button variant="primary" size="sm" wire:click="generateAiReview" wire:confirm="This sends the lead name, company, source, and inquiry text to OpenAI for processing. The email address is not sent. Continue?">{{ $this->selectedLead->ai_generated_at ? 'Regenerate suggestions' : 'Generate suggestions' }}</flux:button>
                        @else
                            <flux:button variant="primary" size="sm" disabled>AI key not configured</flux:button>
                        @endif
                    </div>
                    <p class="mt-3 text-xs leading-5 text-zinc-600 dark:text-zinc-400">OpenAI receives the lead's name, company, source, and inquiry text when you generate suggestions. Email is excluded. Suggestions do not change status or send replies.</p>
                    @unless ($this->isAiAvailable)<p class="mt-2 text-xs leading-5 text-amber-700 dark:text-amber-300">AI belum dikonfigurasi. Anda tetap bisa menentukan status lead secara manual dan menulis draf balasan di bawah. Jika nanti sudah memiliki key, tambahkan melalui <a href="{{ route('ai.edit') }}" wire:navigate class="font-semibold underline">Settings → AI integration</a>.</p>@endunless
                    @if ($aiError)<p role="alert" class="mt-3 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700 dark:bg-red-950/40 dark:text-red-300">{{ $aiError }}</p>@endif
                    @if ($this->selectedLead->ai_generated_at)
                        <div class="mt-5 grid gap-4 border-t border-blue-100 pt-4 dark:border-blue-950 sm:grid-cols-[auto_1fr]">
                            <div class="rounded-xl bg-white px-4 py-3 text-center shadow-sm dark:bg-zinc-900"><p class="text-2xl font-semibold text-zinc-950 dark:text-white">{{ $this->selectedLead->score }}<span class="text-sm font-normal text-zinc-500">/100</span></p><p class="mt-1 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">Suggested fit</p></div>
                            <div><span class="inline-flex rounded-full px-2.5 py-1 text-xs font-semibold {{ ['qualified'=>'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200','review'=>'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200','disqualified'=>'bg-zinc-200 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-200'][$this->selectedLead->ai_recommendation] ?? 'bg-zinc-100 text-zinc-700' }}">AI suggests: {{ str($this->selectedLead->ai_recommendation)->replace('_', ' ')->title() }}</span><p class="mt-2 text-sm leading-6 text-zinc-700 dark:text-zinc-300">{{ $this->selectedLead->ai_reasoning }}</p><p class="mt-1 text-[11px] text-zinc-500">Generated {{ $this->selectedLead->ai_generated_at->diffForHumans() }}. This is guidance, not an automatic decision.</p></div>
                        </div>
                    @endif
                </section>

                <section class="space-y-3">
                    <div class="flex flex-wrap items-center justify-between gap-2"><div><p class="text-xs font-semibold uppercase tracking-wider text-zinc-500">Reply draft</p><p class="mt-1 text-xs text-zinc-500">Edit freely. Approval applies only to the exact saved text.</p></div>
                        @if ($this->selectedLead->reply_approved_at && $this->selectedLead->reply_draft === $replyDraft)<span class="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300"><span class="size-1.5 rounded-full bg-emerald-500"></span> Approved · not sent</span>@elseif ($this->selectedLead->reply_approved_at)<span class="rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-700 dark:bg-amber-950/50 dark:text-amber-300">Edited · approval required</span>@elseif ($this->selectedLead->reply_draft)<span class="rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">Needs review</span>@endif
                    </div>
                    <flux:textarea wire:model.live.debounce.300ms="replyDraft" aria-label="Reply draft" placeholder="Generate or write a reply draft…" rows="6" />
                    @error('replyDraft')<p class="text-xs text-red-600">{{ $message }}</p>@enderror
                    <div class="flex flex-wrap justify-end gap-2"><flux:button variant="outline" wire:click="saveReplyDraft" :disabled="!$replyDraft">Save draft</flux:button><flux:button variant="primary" wire:click="approveReplyDraft" :disabled="!$replyDraft">Approve draft</flux:button></div>
                    <p class="text-right text-xs text-zinc-500">Approval only records your review. This app does not send messages.</p>
                </section>

                <div><p class="text-xs font-semibold uppercase tracking-wider text-zinc-500">Recent activity</p><div class="mt-3 space-y-3">@forelse ($this->selectedLead->activities as $activity)<div class="flex gap-3"><span class="mt-1.5 size-2 shrink-0 rounded-full {{ $activity->type === 'lead_created' ? 'bg-blue-500' : ($activity->type === 'ai_reviewed' ? 'bg-violet-500' : 'bg-emerald-500') }}"></span><div><p class="text-sm text-zinc-700 dark:text-zinc-300">{{ $activity->description }}</p><p class="mt-0.5 text-xs text-zinc-500">{{ $activity->created_at->diffForHumans() }}</p></div></div>@empty<p class="text-sm text-zinc-500">No activity recorded yet.</p>@endforelse</div></div>
                <div class="flex justify-end"><flux:button variant="outline" wire:click="closeLead">Close</flux:button></div>
            </div>
        @endif
    </flux:modal>
</div>
