<?php

namespace App\Services;

use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class SocialProviderSettings
{
    private const PROVIDERS = ['google', 'facebook'];

    /** @return array{client_id: string, client_secret: string, redirect: string, source: string}|null */
    public function credentials(string $provider): ?array
    {
        $this->ensureProvider($provider);

        $storedId = DB::table('system_settings')->where('key', $provider.'_client_id')->value('value');
        $storedSecret = DB::table('system_settings')->where('key', $provider.'_client_secret')->value('value');

        if (is_string($storedId) && $storedId !== '' && is_string($storedSecret) && $storedSecret !== '') {
            try {
                return [
                    'client_id' => Crypt::decryptString($storedId),
                    'client_secret' => Crypt::decryptString($storedSecret),
                    'redirect' => (string) config("services.{$provider}.redirect"),
                    'source' => 'admin',
                ];
            } catch (DecryptException) {
                // An APP_KEY rotation or a damaged ciphertext disables saved credentials safely.
                // Fall back to server environment values without exposing stored data.
            }
        }

        $clientId = config("services.{$provider}.client_id");
        $clientSecret = config("services.{$provider}.client_secret");

        if (! is_string($clientId) || trim($clientId) === '' || ! is_string($clientSecret) || trim($clientSecret) === '') {
            return null;
        }

        return [
            'client_id' => $clientId,
            'client_secret' => $clientSecret,
            'redirect' => (string) config("services.{$provider}.redirect"),
            'source' => 'environment',
        ];
    }

    public function isConfigured(string $provider): bool
    {
        return $this->credentials($provider) !== null;
    }

    public function source(string $provider): ?string
    {
        return $this->credentials($provider)['source'] ?? null;
    }

    public function apply(string $provider): bool
    {
        $credentials = $this->credentials($provider);

        if ($credentials === null) {
            return false;
        }

        config([
            "services.{$provider}.client_id" => $credentials['client_id'],
            "services.{$provider}.client_secret" => $credentials['client_secret'],
            "services.{$provider}.redirect" => $credentials['redirect'],
        ]);

        return true;
    }

    public function save(string $provider, string $clientId, string $clientSecret): void
    {
        $this->ensureProvider($provider);

        DB::transaction(function () use ($provider, $clientId, $clientSecret): void {
            foreach ([
                $provider.'_client_id' => trim($clientId),
                $provider.'_client_secret' => trim($clientSecret),
            ] as $key => $value) {
                DB::table('system_settings')->updateOrInsert(
                    ['key' => $key],
                    ['value' => Crypt::encryptString($value), 'updated_at' => now(), 'created_at' => now()],
                );
            }
        });
    }

    public function remove(string $provider): void
    {
        $this->ensureProvider($provider);

        DB::table('system_settings')
            ->whereIn('key', [$provider.'_client_id', $provider.'_client_secret'])
            ->delete();
    }

    private function ensureProvider(string $provider): void
    {
        if (! in_array($provider, self::PROVIDERS, true)) {
            throw new InvalidArgumentException('Unsupported social provider.');
        }
    }
}
