<?php

namespace App\Services;

use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

class OpenAiApiKey
{
    public function get(?int $userId = null): ?string
    {
        $userId ??= auth()->id();
        $encrypted = $userId === null ? null : DB::table('app_settings')
            ->where('user_id', $userId)
            ->where('key', 'openai_api_key')
            ->value('value');

        if (is_string($encrypted) && $encrypted !== '') {
            return Crypt::decryptString($encrypted);
        }

        $environmentKey = config('services.openai.api_key');

        return is_string($environmentKey) && trim($environmentKey) !== '' ? $environmentKey : null;
    }

    public function isConfigured(?int $userId = null): bool
    {
        return $this->get($userId) !== null;
    }

    public function isStoredInApp(?int $userId = null): bool
    {
        $userId ??= auth()->id();

        return $userId !== null && DB::table('app_settings')
            ->where('user_id', $userId)
            ->where('key', 'openai_api_key')
            ->exists();
    }
}
