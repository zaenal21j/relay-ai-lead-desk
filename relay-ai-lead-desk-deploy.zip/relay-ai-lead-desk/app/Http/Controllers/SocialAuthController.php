<?php

namespace App\Http\Controllers;

use App\Models\SocialAccount;
use App\Models\User;
use App\Services\SocialProviderSettings;
use Illuminate\Auth\Events\Registered;
use Illuminate\Database\QueryException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Laravel\Socialite\Facades\Socialite;
use Throwable;

class SocialAuthController extends Controller
{
    private const PROVIDERS = ['google', 'facebook'];

    public function redirect(string $provider, SocialProviderSettings $providerSettings): RedirectResponse
    {
        abort_unless(in_array($provider, self::PROVIDERS, true), 404);

        if (! $providerSettings->apply($provider)) {
            return redirect()->route('login')->with('status', ucfirst($provider).' sign-in is not configured yet. Use email and password for now.');
        }

        session()->forget('social_auth_link_user_id');

        return Socialite::driver($provider)->redirect();
    }

    public function link(string $provider, SocialProviderSettings $providerSettings): RedirectResponse
    {
        abort_unless(in_array($provider, self::PROVIDERS, true), 404);

        if (! $providerSettings->apply($provider)) {
            return redirect()->route('connections.edit')->with('status', ucfirst($provider).' sign-in is not configured yet.');
        }

        session()->put('social_auth_link_user_id', Auth::id());

        return Socialite::driver($provider)->redirect();
    }

    public function callback(Request $request, string $provider, SocialProviderSettings $providerSettings): RedirectResponse
    {
        abort_unless(in_array($provider, self::PROVIDERS, true), 404);

        if (! $providerSettings->apply($provider)) {
            return redirect()->route('login')->with('status', ucfirst($provider).' sign-in is not configured yet. Use email and password for now.');
        }

        try {
            $providerUser = Socialite::driver($provider)->user();
        } catch (Throwable $exception) {
            Log::warning('Social authentication failed.', [
                'provider' => $provider,
                'exception' => $exception::class,
            ]);

            return redirect()->route('login')->with('status', 'Sign-in with '.ucfirst($provider).' could not be completed. Please try again or use email and password.');
        }

        $linkUserId = $request->session()->pull('social_auth_link_user_id');

        if ($linkUserId !== null) {
            return $this->linkProviderAccount($provider, (string) $providerUser->getId(), (int) $linkUserId);
        }

        $identity = SocialAccount::query()
            ->where('provider', $provider)
            ->where('provider_user_id', (string) $providerUser->getId())
            ->with('user')
            ->first();

        if ($identity) {
            Auth::login($identity->user);
            $request->session()->regenerate();

            return redirect()->intended(route('dashboard'));
        }

        $email = mb_strtolower(trim((string) $providerUser->getEmail()));

        if ($email === '' || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            return redirect()->route('register')->with('status', 'This provider did not return an email address. Use email registration or choose another sign-in method.');
        }

        if (User::query()->where('email', $email)->exists()) {
            return redirect()->route('login')->with('status', 'An account already uses this email. Sign in with that account, then connect '.ucfirst($provider).' in Settings → Connections.');
        }

        $providerEmailVerified = $provider === 'google'
            && (bool) data_get($providerUser->user, 'verified_email', false);

        try {
            $user = DB::transaction(function () use ($provider, $providerUser, $email, $providerEmailVerified): User {
                $name = trim((string) $providerUser->getName());
                $user = User::create([
                    'name' => $name !== '' ? $name : Str::before($email, '@'),
                    'email' => $email,
                    'password' => Str::random(64),
                ]);

                if ($providerEmailVerified || app()->isLocal()) {
                    $user->forceFill([
                        'email_verified_at' => now(),
                        'is_admin' => app()->isLocal() && User::query()->count() === 1,
                    ])->save();
                }

                $user->socialAccounts()->create([
                    'provider' => $provider,
                    'provider_user_id' => (string) $providerUser->getId(),
                ]);

                return $user;
            });
        } catch (QueryException $exception) {
            Log::notice('Social account creation conflicted with an existing record.', [
                'provider' => $provider,
                'exception' => $exception::class,
            ]);

            return redirect()->route('login')->with('status', 'An account with this email or social profile already exists. Sign in with your existing method.');
        }

        try {
            event(new Registered($user));
        } catch (Throwable $exception) {
            Log::warning('Social account was created but its verification notification could not be sent.', [
                'provider' => $provider,
                'exception' => $exception::class,
            ]);
        }

        Auth::login($user);
        $request->session()->regenerate();

        return $user->hasVerifiedEmail()
            ? redirect()->route('dashboard')
            : redirect()->route('verification.notice');
    }

    private function linkProviderAccount(string $provider, string $providerUserId, int $userId): RedirectResponse
    {
        if (! Auth::check() || Auth::id() !== $userId) {
            return redirect()->route('login')->with('status', 'Your session expired before the account could be connected. Sign in and try again.');
        }

        $identity = SocialAccount::query()
            ->where('provider', $provider)
            ->where('provider_user_id', $providerUserId)
            ->first();

        if ($identity && $identity->user_id !== $userId) {
            return redirect()->route('connections.edit')->with('status', 'This social account is already connected to another Relay account.');
        }

        $existingProvider = SocialAccount::query()
            ->where('user_id', $userId)
            ->where('provider', $provider)
            ->first();

        if ($existingProvider && $existingProvider->provider_user_id !== $providerUserId) {
            return redirect()->route('connections.edit')->with('status', 'A different '.ucfirst($provider).' account is already connected.');
        }

        if (! $identity) {
            SocialAccount::create([
                'user_id' => $userId,
                'provider' => $provider,
                'provider_user_id' => $providerUserId,
            ]);
        }

        return redirect()->route('connections.edit')->with('status', ucfirst($provider).' sign-in is connected to your account.');
    }
}
