<?php

namespace App\Livewire\Leads;

use App\Models\Lead;
use App\Services\OpenAiApiKey;
use App\Services\OpenAiLeadAssistant;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use Livewire\Attributes\Computed;
use Livewire\Component;
use Livewire\WithPagination;

class Index extends Component
{
    use WithPagination;

    public string $search = '';

    public string $status = 'all';

    public bool $showCreateModal = false;

    public ?int $selectedLeadId = null;

    public ?string $notice = null;

    public ?string $aiError = null;

    public string $replyDraft = '';

    public string $name = '';

    public string $email = '';

    public string $company = '';

    public string $source = '';

    public string $message = '';

    public function updatedSearch(): void
    {
        $this->resetPage();
    }

    public function updatedStatus(): void
    {
        $this->resetPage();
    }

    #[Computed]
    public function leads()
    {
        return auth()->user()->leads()
            ->when($this->status !== 'all', fn (Builder $query) => $query->where('status', $this->status))
            ->when(trim($this->search) !== '', function (Builder $query) {
                $term = '%'.trim($this->search).'%';
                $query->where(fn (Builder $nested) => $nested
                    ->where('name', 'like', $term)
                    ->orWhere('email', 'like', $term)
                    ->orWhere('company', 'like', $term));
            })
            ->latest()
            ->paginate(10);
    }

    #[Computed]
    public function selectedLead(): ?Lead
    {
        return $this->selectedLeadId
            ? auth()->user()->leads()->with(['activities' => fn ($query) => $query->latest()->limit(5)])->findOrFail($this->selectedLeadId)
            : null;
    }

    #[Computed]
    public function isAiAvailable(): bool
    {
        return app(OpenAiApiKey::class)->isConfigured(auth()->id());
    }

    public function openCreateModal(): void
    {
        $this->resetValidation();
        $this->reset(['name', 'email', 'company', 'source', 'message']);
        $this->showCreateModal = true;
    }

    public function viewLead(int $leadId): void
    {
        $lead = auth()->user()->leads()->findOrFail($leadId);
        $this->selectedLeadId = $lead->id;
        $this->replyDraft = $lead->reply_draft ?? '';
        $this->aiError = null;
        $this->notice = null;
    }

    public function closeLead(): void
    {
        $this->selectedLeadId = null;
        $this->replyDraft = '';
        $this->aiError = null;
        unset($this->selectedLead);
    }

    private function selectedLeadForCurrentUser(): Lead
    {
        abort_if($this->selectedLeadId === null, 404);

        return auth()->user()->leads()->findOrFail($this->selectedLeadId);
    }

    public function generateAiReview(OpenAiLeadAssistant $assistant): void
    {
        $lead = $this->selectedLeadForCurrentUser();

        try {
            $review = $assistant->review($lead);
        } catch (\Throwable) {
            Log::warning('Lead AI review failed.', ['lead_id' => $lead->id]);
            $this->aiError = 'The AI review could not be completed. Check the server configuration and try again.';

            return;
        }

        DB::transaction(function () use ($lead, $review): void {
            $lead->update([
                'score' => $review['score'],
                'ai_recommendation' => $review['recommendation'],
                'ai_reasoning' => $review['reasoning'],
                'ai_generated_at' => now(),
                'reply_draft' => $review['reply_draft'],
                'reply_approved_at' => null,
                'reply_approved_by' => null,
            ]);
            $lead->activities()->create([
                'user_id' => auth()->id(),
                'type' => 'ai_reviewed',
                'description' => 'AI qualification and reply draft generated for human review.',
            ]);
        });

        $this->replyDraft = $review['reply_draft'];
        $this->aiError = null;
        $this->notice = 'AI suggestions are ready. Review them before changing the lead status or approving the reply.';
        unset($this->selectedLead, $this->leads);
    }

    public function saveReplyDraft(): void
    {
        $validated = $this->validate(['replyDraft' => ['required', 'string', 'max:5000']]);
        $lead = $this->selectedLeadForCurrentUser();
        $changed = $lead->reply_draft !== $validated['replyDraft'];

        $lead->update([
            'reply_draft' => $validated['replyDraft'],
            ...($changed ? ['reply_approved_at' => null, 'reply_approved_by' => null] : []),
        ]);

        if ($changed) {
            $lead->activities()->create([
                'user_id' => auth()->id(),
                'type' => 'reply_edited',
                'description' => 'Reply draft edited and saved. Approval cleared until reviewed again.',
            ]);
        }

        $this->notice = $changed ? 'Draft saved. Review and approve it before using it.' : 'No draft changes to save.';
        unset($this->selectedLead);
    }

    public function approveReplyDraft(): void
    {
        $validated = $this->validate(['replyDraft' => ['required', 'string', 'max:5000']]);
        $lead = $this->selectedLeadForCurrentUser();

        DB::transaction(function () use ($lead, $validated): void {
            $lead->update([
                'reply_draft' => $validated['replyDraft'],
                'reply_approved_at' => now(),
                'reply_approved_by' => auth()->id(),
            ]);
            $lead->activities()->create([
                'user_id' => auth()->id(),
                'type' => 'reply_approved',
                'description' => 'Reply draft approved by a human reviewer. It has not been sent.',
            ]);
        });

        $this->notice = 'Reply approved and saved. It has not been sent.';
        unset($this->selectedLead);
    }

    public function saveLead(): void
    {
        $validated = $this->validate([
            'name' => ['required', 'string', 'max:120'],
            'email' => ['required', 'email', 'max:190', Rule::unique('leads', 'email')->where('user_id', auth()->id())],
            'company' => ['nullable', 'string', 'max:160'],
            'source' => ['nullable', 'string', 'max:100'],
            'message' => ['nullable', 'string', 'max:5000'],
        ]);

        DB::transaction(function () use ($validated): void {
            $lead = auth()->user()->leads()->create($validated + ['status' => 'new']);
            $lead->activities()->create([
                'user_id' => auth()->id(),
                'type' => 'lead_created',
                'description' => 'Lead added to the pipeline.',
                'to_status' => 'new',
            ]);
        });

        $this->showCreateModal = false;
        $this->reset(['name', 'email', 'company', 'source', 'message']);
        unset($this->leads);
        $this->notice = 'Lead saved to your workspace.';
    }

    public function updateStatus(int $leadId, string $status): void
    {
        abort_unless(in_array($status, ['new', 'review', 'qualified', 'disqualified'], true), 422);

        DB::transaction(function () use ($leadId, $status): void {
            $lead = auth()->user()->leads()->findOrFail($leadId);
            $previousStatus = $lead->status;

            if ($previousStatus === $status) {
                return;
            }

            $lead->update(['status' => $status]);
            $lead->activities()->create([
                'user_id' => auth()->id(),
                'type' => 'status_changed',
                'description' => 'Status changed from '.str_replace('_', ' ', $previousStatus).' to '.str_replace('_', ' ', $status).'.',
                'from_status' => $previousStatus,
                'to_status' => $status,
            ]);
        });
        unset($this->leads, $this->selectedLead);
    }

    public function render()
    {
        return view('livewire.leads.index')->layout('layouts.app')->title('Leads');
    }
}
