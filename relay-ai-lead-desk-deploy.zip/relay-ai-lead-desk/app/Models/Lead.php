<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable(['user_id', 'name', 'email', 'company', 'source', 'status', 'score', 'message', 'ai_recommendation', 'ai_reasoning', 'ai_generated_at', 'reply_draft', 'reply_approved_at', 'reply_approved_by'])]
class Lead extends Model
{
    protected function casts(): array
    {
        return [
            'ai_generated_at' => 'datetime',
            'reply_approved_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /** @return HasMany<LeadActivity, $this> */
    public function activities(): HasMany
    {
        return $this->hasMany(LeadActivity::class);
    }
}
